package com.example.homeappliancecontroller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.view.View;
import android.widget.TextView;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Set;


public class MainActivity extends AppCompatActivity {
    OutputStream outputStream;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView) findViewById(R.id.StatusArea);
        text.setText("Ready");

        BluetoothAdapter ba;
        ba = BluetoothAdapter.getDefaultAdapter();
        //TextView text = (TextView) findViewById(R.id.textLED);

        Set<BluetoothDevice> pairedDevices;
        try {
            pairedDevices = ba.getBondedDevices();
            if(pairedDevices.size() > 0) {
                Object[] devices = (Object []) pairedDevices.toArray();
                BluetoothDevice device = (BluetoothDevice) devices[0];
                text.setText(text.getText() + "\nBluetooth Device: " + device.getName());
                ParcelUuid[] uuids = device.getUuids();
                BluetoothSocket socket = device.createRfcommSocketToServiceRecord(uuids[0].getUuid());
                socket.connect();
                outputStream = socket.getOutputStream();
            }
            else text.setText("No Bluetooth Device Connected\nPair Bluetooth Device and Restart this App");
        }
        catch (Exception e){
            text.setText("Can't connect to Bluetooth Device. Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void lampOnSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(1).getBytes(StandardCharsets.UTF_8));
            text.setText("Lamp switched on");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void lampOffSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(2).getBytes(StandardCharsets.UTF_8));
            text.setText("Lamp switched off");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void fanOnSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(3).getBytes(StandardCharsets.UTF_8));
            text.setText("Fan switched on");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void fanOffSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(4).getBytes(StandardCharsets.UTF_8));
            text.setText("Fan switched off");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void LEDOnSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(5).getBytes(StandardCharsets.UTF_8));
            text.setText("LED switched on");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void LEDOffSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(6).getBytes(StandardCharsets.UTF_8));
            text.setText("LED switched off");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void buzzerOnSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(7).getBytes(StandardCharsets.UTF_8));
            text.setText("Buzzer switched on");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }

    public void buzzerOffSwitchClicked(View view) {
        try {
            outputStream.write(String.valueOf(8).getBytes(StandardCharsets.UTF_8));
            text.setText("Buzzer switched off");
        } catch (Exception e) {
            text.setText("Exception. msg=" + e.getMessage());
            e.printStackTrace();
        }
    }
}